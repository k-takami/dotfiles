package pkgA;

public class PkgTest2 {
	public void test() {
		System.out.println("this is pkgA.PkgTest2");
	}
}
