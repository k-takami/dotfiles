package pkgA.pkgB;

public class PkgTest3 {
	public void test() {
		System.out.println("this is pkgA.pkgB.PkgTest3");
	}
}
