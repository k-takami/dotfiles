import java.awt.*;
import java.applet.*;

public class AppletTest extends Applet {
	public void paint(Graphics g) {
		g.drawString("Hello World!!", 60, 30);
	}
}
