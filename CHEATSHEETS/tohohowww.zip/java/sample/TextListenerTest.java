import java.awt.*;
import java.awt.event.*;

public class TextListenerTest extends Frame implements TextListener {
	TextListenerTest () {
		super("TextListenerTest");
		TextField tf1 = new TextField();
		tf1.addTextListener(this);
		add(tf1);
		setSize(200, 100);
		show();
	}
	public void textValueChanged(TextEvent e) {
		TextField tf = (TextField)e.getSource();
		System.out.println(tf.getText());
	}
	public static void main(String [] args) {
		new TextListenerTest();
	}
}
