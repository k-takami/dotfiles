class JarTest {
	public static void main(String[] args) {
		new JarTest2();
	}
}

class JarTest2 {
	JarTest2() {
		System.out.println("Hello!!");
	}
}
