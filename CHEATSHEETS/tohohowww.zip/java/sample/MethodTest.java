class MethodTest {
	public static void main(String[] args) {
		System.out.println(add(3, 5));
	}
	static int add(int x, int y) {
		return (x + y);
	}	
}
