import java.io.File;
import java.io.IOException;

class ExecTest {
	public static void main(String[] args) {
		try {
			Runtime.getRuntime().exec("notepad.exe");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
