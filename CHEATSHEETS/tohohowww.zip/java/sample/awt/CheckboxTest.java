import java.awt.*;

public class CheckboxTest extends Frame {
	public static void main(String [] args) {
		new CheckboxTest();
	}
	CheckboxTest() {
		super("CheckboxTest");
		setSize(200, 100);
		setLayout(new FlowLayout());
		Checkbox c1 = new Checkbox("OK?");
		add(c1);
		show();
	}
}
