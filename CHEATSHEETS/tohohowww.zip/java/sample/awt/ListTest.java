import java.awt.*;

public class ListTest extends Frame {
	public static void main(String [] args) {
		new ListTest();
	}
	ListTest() {
		super("ListTest");
		setSize(200, 100);
		setLayout(new FlowLayout());
		List list1 = new List();
		list1.add("ListA");
		list1.add("ListB");
		list1.add("ListC");
		list1.add("ListD");
		list1.add("ListE");
		add(list1);
		show();
	}
}
