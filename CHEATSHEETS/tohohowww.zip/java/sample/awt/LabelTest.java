import java.awt.*;

public class LabelTest extends Frame {
	public static void main(String [] args) {
		new LabelTest();
	}
	LabelTest() {
		super("LabelTest");
		setSize(200, 100);
		setLayout(new FlowLayout());
		Label l1 = new Label("HelloWorld!!");
		add(l1);
		show();
	}
}
