import java.awt.*;

public class TextFieldTest extends Frame {
	public static void main(String [] args) {
		new TextFieldTest();
	}
	TextFieldTest() {
		super("TextFieldTest");
		setSize(200, 100);
		setLayout(new FlowLayout());
		TextField t1 = new TextField("Hello World!!");
		add(t1);
		show();
	}
}
