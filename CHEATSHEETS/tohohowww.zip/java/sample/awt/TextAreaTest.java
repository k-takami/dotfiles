import java.awt.*;

public class TextAreaTest extends Frame {
	public static void main(String [] args) {
		new TextAreaTest();
	}
	TextAreaTest() {
		super("TextAreaTest");
		setSize(200, 100);
		setLayout(new FlowLayout());
		TextArea b1 = new TextArea("Hello World!!", 3, 20);
		add(b1);
		show();
	}
}
