import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;

class JTabbedPaneTest extends JFrame implements ChangeListener {
	JTree tree = new JTree();
	JTable table = new JTable(3, 3);

	JTabbedPaneTest() {

		JTabbedPane tabbedPane = new JTabbedPane();
		tabbedPane.add("AAA", tree);
		tabbedPane.add("BBB", table);
		tabbedPane.addChangeListener(this);
		getContentPane().add(tabbedPane);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("JTabbedPaneTest");
		setSize(200, 150);
		setVisible(true);
	}
	public void stateChanged(ChangeEvent e) {
		JTabbedPane t = (JTabbedPane)e.getSource();
		if (t.getSelectedComponent() == tree) {
			System.out.println("Tree");
		} else {
			System.out.println("Table");
		}
	}
	public static void main(String args[]) {
		new JTabbedPaneTest();
	}
}
