import java.awt.*;
import javax.swing.*;

class JScrollPaneTest extends JFrame {
	JScrollPaneTest() {
		JTextArea textArea = new JTextArea();
		textArea.setWrapStyleWord(true);
		textArea.setLineWrap(false);

		JScrollPane scrollPane = new JScrollPane(textArea);
		scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setPreferredSize(new Dimension(200, 100));
		getContentPane().add(scrollPane, BorderLayout.CENTER);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("JScrollPaneTest");
		setSize(200, 100);
		setVisible(true);
	}
	public static void main(String[] args) {
		new JScrollPaneTest();
	}
}
