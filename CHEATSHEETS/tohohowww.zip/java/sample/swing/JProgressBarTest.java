import java.awt.*;
import javax.swing.*;

class JProgressBarTest extends JFrame {
	JProgressBarTest() {
		getContentPane().setLayout(new FlowLayout());

		JProgressBar pb = new JProgressBar(1, 100);
		pb.setValue(50);
		getContentPane().add(pb);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("JProgressBarTest");
		setSize(200, 100);
		setVisible(true);
	}
	public static void main(String[] args) {
		new JProgressBarTest();
	}
}
