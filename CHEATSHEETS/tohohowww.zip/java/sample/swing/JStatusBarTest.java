import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;

class JStatusBarTest extends JFrame {
	JStatusBarTest() {
		getContentPane().setLayout(new BorderLayout());

		JTextArea textArea = new JTextArea();
		getContentPane().add(textArea, BorderLayout.CENTER);

		JLabel statusBar = new JLabel("Ready.");
		getContentPane().add(statusBar, BorderLayout.SOUTH);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("JStatusBarTest");
		setSize(200, 100);
		setVisible(true);
	}
	public static void main(String args[]) {
		new JStatusBarTest();
	}
}
