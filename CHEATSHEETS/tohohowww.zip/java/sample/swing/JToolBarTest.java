import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class JToolBarTest extends JFrame implements ActionListener {
	public JToolBarTest() {
		getContentPane().setLayout(new BorderLayout());

		JToolBar toolBar = new JToolBar();
		toolBar.setFloatable(true);
		getContentPane().add(toolBar, BorderLayout.NORTH);

		JButton btnNew = new JButton(new ImageIcon("new.gif"));
		btnNew.setActionCommand("New");
		btnNew.addActionListener(this);
		toolBar.add(btnNew);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("JToolBarTest");
		setSize(200, 100);
		setVisible(true);
	}
	public void actionPerformed(ActionEvent e) {
		System.out.println(e.getActionCommand());
	}
	public static void main(String[] args) {
		new JToolBarTest();
	}
}
