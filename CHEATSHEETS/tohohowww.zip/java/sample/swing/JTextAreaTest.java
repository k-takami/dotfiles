import java.awt.*;
import javax.swing.*;

class JTextAreaTest extends JFrame {
	JTextAreaTest() {
		getContentPane().setLayout(new FlowLayout());

		JTextArea ta = new JTextArea("Hello World!!", 4, 15);
		getContentPane().add(ta);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("JTextAreaTest");
		setSize(200, 100);
		setVisible(true);
	}
	public static void main(String[] args) {
		new JTextAreaTest();
	}
}
