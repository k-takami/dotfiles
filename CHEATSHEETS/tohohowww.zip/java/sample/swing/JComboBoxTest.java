import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class JComboBoxTest extends JFrame implements ActionListener {
	JComboBoxTest() {
		getContentPane().setLayout(new FlowLayout());

		JComboBox cb = new JComboBox();
		cb.addItem("ComboA");
		cb.addItem("ComboB");
		cb.addItem("ComboC");
		cb.addActionListener(this);
		getContentPane().add(cb);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("JComboBoxTest");
		setSize(200, 120);
		setVisible(true);
	}
	public void actionPerformed(ActionEvent e) {
		JComboBox cb = (JComboBox)e.getSource();
		System.out.println(cb.getSelectedItem());
	}
	public static void main(String[] args) {
		new JComboBoxTest();
	}
}
