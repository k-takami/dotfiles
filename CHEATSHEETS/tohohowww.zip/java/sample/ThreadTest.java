class ThreadTest {
	public static void main(String[] args) {
		ThreadTestThread tt = new ThreadTestThread();
		tt.start();
		for (int i = 0; i < 1000; i++) {
			System.out.print('.');
		}
	}
}

class ThreadTestThread extends Thread {
	public void run() {
		for (int i = 0; i < 1000; i++) {
			System.out.print('o');
		}
	}
}
