import java.awt.*;
import java.awt.event.*;

public class MouseListenerTest extends Frame implements MouseListener {
	MouseListenerTest() {
		super("MouseListenerTest");
		this.addMouseListener(this);
		setSize(200, 100);
		show();
	}
	public void mouseClicked(MouseEvent e) {
		System.out.println("mouseClicked");
	}
	public void mousePressed(MouseEvent e) {
		System.out.println("mousePressed");
	}
	public void mouseReleased(MouseEvent e) {
		System.out.println("mouseReleased");
	}
	public void mouseEntered(MouseEvent e) {
		System.out.println("mouseEntered");
	}
	public void mouseExited(MouseEvent e) {
		System.out.println("mouseExited");
	}
	public static void main(String [] args) {
		new MouseListenerTest();
	}
}
