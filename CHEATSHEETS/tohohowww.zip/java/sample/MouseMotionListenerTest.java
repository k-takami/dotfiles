import java.awt.*;
import java.awt.event.*;

public class MouseMotionListenerTest extends Frame implements MouseMotionListener {
	MouseMotionListenerTest () {
		super("MouseMotionListenerTest");
		addMouseMotionListener(this);
		setSize(200, 100);
		show();
	}
	public void mouseDragged(MouseEvent e) {
		System.out.println("D: " + e.getX() + ", " + e.getY());
	}
	public void mouseMoved(MouseEvent e) {
		System.out.println("M: " + e.getX() + ", " + e.getY());
	}
	public static void main(String [] args) {
		new MouseMotionListenerTest();
	}
}
