import java.util.*;

class ArrayListTest {
	public static void main(String[] args) {
		ArrayList list = new ArrayList();
		list.add("AAA");
		list.add("BBB");
		list.add("CCC");
		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i));
		}
	}
}
