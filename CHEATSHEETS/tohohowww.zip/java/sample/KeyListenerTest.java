import java.awt.*;
import java.awt.event.*;

public class KeyListenerTest extends Frame implements KeyListener {
	KeyListenerTest() {
		super("KeyListenerTest");
		TextField tf1 = new TextField();
		tf1.addKeyListener(this);
		add(tf1);
		setSize(200, 100);
		show();
	}
	public void keyPressed(KeyEvent e) {
		System.out.println("Press: " + e.getKeyText(e.getKeyCode()));
	}
	public void keyReleased(KeyEvent e) {
		System.out.println("Release: " + e.getKeyText(e.getKeyCode()));
	}
	public void keyTyped(KeyEvent e) {
		System.out.println("Type: " + e.getKeyChar());
	}
	public static void main(String [] args) {
		new KeyListenerTest();
	}
}
