class PkgTest1 {
	public static void main(String[] args) {
		pkgA.PkgTest2 o2 = new pkgA.PkgTest2();
		pkgA.pkgB.PkgTest3 o3 = new pkgA.pkgB.PkgTest3();
		o2.test();
		o3.test();
	}
}
