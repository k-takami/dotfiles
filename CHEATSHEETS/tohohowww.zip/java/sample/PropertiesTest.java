import java.util.*;

class PropertiesTest {
	public static void main(String[] args) {
		Properties prop = System.getProperties();
		prop.list(System.out);
	}
}
