import java.util.*;

class TreeSetTest {
	public static void main(String[] args) {
		TreeSet set = new TreeSet();
		set.add("CCC");
		set.add("AAA");
		set.add("BBB");
		set.add("AAA");
		Iterator it = set.iterator();
		while (it.hasNext()) {
			System.out.println(it.next());
		}
	}
}
