import java.util.*;

class TreeMapTest {
	public static void main(String[] args) {
		TreeMap map = new TreeMap();
		map.put("Name", "Tanaka");
		map.put("Age", new Integer(26));
		Iterator it = map.keySet().iterator();
		while (it.hasNext()) {
			Object o = it.next();
			System.out.println(o + " = " + map.get(o));
		}
	}
}
