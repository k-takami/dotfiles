import java.awt.*;
import java.awt.event.*;

public class ActionListenerTest2 extends Frame {
	ActionListenerTest2() {
		super("ActionListenerTest2");
		Button b1 = new Button("BUTTON1");
		b1.addActionListener(new MyActionListener());
		add(b1);
		setSize(200, 100);
		show();
	}
	class MyActionListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			System.exit(0);
		}
	}
	public static void main(String [] args) {
		new ActionListenerTest2();
	}
}
