class RunnableTest {
	public static void main(String[] args) {
		RunnableTestThread tt = new RunnableTestThread();
		Thread t = new Thread(tt);
		t.start();
		for (int i = 0; i < 1000; i++) {
			System.out.print('.');
		}
	}
}

class RunnableTestThread implements Runnable {
	public void run() {
		for (int i = 0; i < 1000; i++) {
			System.out.print('o');
		}
	}
}
