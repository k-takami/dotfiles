import java.util.*;

class HashSetTest {
	public static void main(String[] args) {
		HashSet set = new HashSet();
		set.add("AAA");
		set.add("BBB");
		set.add("CCC");
		set.add("AAA");
		Iterator it = set.iterator();
		while (it.hasNext()) {
			System.out.println(it.next());
		}
	}
}
